package org.firstinspires.ftc.teamcode.Swerb506.utility.pathplanner.path;

import org.firstinspires.ftc.teamcode.Swerb506.utility.pathplanner.util.GeometryUtil;
import org.firstinspires.ftc.teamcode.Swerb506.utility.math.geometry.Rotation2d;
import org.firstinspires.ftc.teamcode.Swerb506.utility.math.geometry.Translation2d;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** A bezier curve segment */
public class PathSegment {
  /** The resolution used during path generation */
  public static final double RESOLUTION = 0.05;

  private final List<PathPoint> segmentPoints;

  /**
   * Generate a new path segment
   *
   * @param p1 Start anchor point
   * @param p2 Start next control
   * @param p3 End prev control
   * @param p4 End anchor point
   * @param targetHolonomicRotations Rotation targets for within this segment
   * @param constraintZones Constraint zones for within this segment
   * @param endSegment Is this the last segment in the path
   */
  public PathSegment(
      Translation2d p1,
      Translation2d p2,
      Translation2d p3,
      Translation2d p4,
      List<RotationTarget> targetHolonomicRotations,
      List<ConstraintsZone> constraintZones,
      boolean endSegment) {
    this.segmentPoints = new ArrayList<>();

    for (double t = 0.0; t < 1.0; t += RESOLUTION) {
      Rotation2d holonomicRotation = null;

      if (!targetHolonomicRotations.isEmpty()) {
        if (Math.abs(targetHolonomicRotations.get(0).getPosition() - t)
            <= Math.abs(
                targetHolonomicRotations.get(0).getPosition() - Math.min(t + RESOLUTION, 1.0))) {
          holonomicRotation = targetHolonomicRotations.remove(0).getTarget();
        }
      }

      Optional<ConstraintsZone> currentZone = findConstraintsZone(constraintZones, t);

      if (currentZone.isPresent()) {
        this.segmentPoints.add(
            new PathPoint(
                GeometryUtil.cubicLerp(p1, p2, p3, p4, t),
                holonomicRotation,
                currentZone.get().getConstraints()));
      } else {
        this.segmentPoints.add(
            new PathPoint(GeometryUtil.cubicLerp(p1, p2, p3, p4, t), holonomicRotation));
      }
    }

    if (endSegment) {
      Rotation2d holonomicRotation =
          targetHolonomicRotations.isEmpty()
              ? null
              : targetHolonomicRotations.remove(0).getTarget();
      this.segmentPoints.add(
          new PathPoint(GeometryUtil.cubicLerp(p1, p2, p3, p4, 1.0), holonomicRotation));
    }
  }

  /**
   * Generate a new path segment without constraint zones or rotation targets
   *
   * @param p1 Start anchor point
   * @param p2 Start next control
   * @param p3 End prev control
   * @param p4 End anchor point
   * @param endSegment Is this the last segment in the path
   */
  public PathSegment(
      Translation2d p1, Translation2d p2, Translation2d p3, Translation2d p4, boolean endSegment) {
    this(p1, p2, p3, p4, new ArrayList<>(), new ArrayList<>(), endSegment);
  }

  /**
   * Get the path points for this segment
   *
   * @return Path points for this segment
   */
  public List<PathPoint> getSegmentPoints() {
    return segmentPoints;
  }

  private Optional<ConstraintsZone> findConstraintsZone(List<ConstraintsZone> zones, double t) {
    return zones.stream().filter(zone -> zone.isWithinZone(t)).findFirst();
  }
}
